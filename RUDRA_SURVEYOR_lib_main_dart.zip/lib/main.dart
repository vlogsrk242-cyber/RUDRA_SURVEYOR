import 'package:flutter/material.dart';

void main() {
  runApp(const RudraSurveyorApp());
}

class RudraSurveyorApp extends StatelessWidget {
  const RudraSurveyorApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'RUDRA SURVEYOR',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        fontFamily: 'sans',
        colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF0878D1)),
        scaffoldBackgroundColor: const Color(0xFFF5F8FC),
      ),
      home: const HomeShell(),
    );
  }
}

class HomeShell extends StatefulWidget {
  const HomeShell({super.key});

  @override
  State<HomeShell> createState() => _HomeShellState();
}

class _HomeShellState extends State<HomeShell> {
  int index = 0;

  final pages = const [
    HomePage(),
    SimplePage(title: 'History', icon: Icons.history, subtitle: 'તમારા અગાઉના નોધ અને માપણી અહીં દેખાશે.'),
    SimplePage(title: 'Map', icon: Icons.map_outlined, subtitle: 'GPS અને નકશા સંબંધિત સુવિધાઓ અહીં તૈયાર રહેશે.'),
    SimplePage(title: 'Profile', icon: Icons.person_outline, subtitle: 'Surveyor profile અને app settings.'),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(child: pages[index]),
      bottomNavigationBar: NavigationBar(
        selectedIndex: index,
        onDestinationSelected: (value) => setState(() => index = value),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'Home'),
          NavigationDestination(icon: Icon(Icons.receipt_long_outlined), selectedIcon: Icon(Icons.receipt_long), label: 'History'),
          NavigationDestination(icon: Icon(Icons.map_outlined), selectedIcon: Icon(Icons.map), label: 'Map'),
          NavigationDestination(icon: Icon(Icons.person_outline), selectedIcon: Icon(Icons.person), label: 'Profile'),
        ],
      ),
    );
  }
}

class HomePage extends StatelessWidget {
  const HomePage({super.key});

  void open(BuildContext context, String title, IconData icon, String text) {
    Navigator.of(context).push(
      MaterialPageRoute(
        builder: (_) => SimplePage(title: title, icon: icon, subtitle: text),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final width = MediaQuery.sizeOf(context).width;
    final horizontal = width >= 700 ? 36.0 : 16.0;

    return CustomScrollView(
      slivers: [
        SliverToBoxAdapter(
          child: Padding(
            padding: EdgeInsets.fromLTRB(horizontal, 12, horizontal, 0),
            child: const _HeroHeader(),
          ),
        ),
        SliverPadding(
          padding: EdgeInsets.fromLTRB(horizontal, 18, horizontal, 14),
          sliver: SliverGrid(
            delegate: SliverChildListDelegate([
              _FeatureCard(
                tag: 'OP1',
                title: 'જમીન માપણી નોંધ',
                description: 'માલિકની માહિતી, ગામ, તાલુકો, મોબાઇલ, સર્વે નંબર, તારીખ, કુલ પેમેન્ટ અને PDF રિપોર્ટ.',
                icon: Icons.assignment_ind_outlined,
                iconColor: const Color(0xFF0878D1),
                background: const Color(0xFFEAF5FF),
                onTap: () => open(context, 'જમીન માપણી નોંધ', Icons.assignment_ind_outlined, 'માલિક અને માપણીની વિગતો સાચવવા માટેનું પેજ.'),
              ),
              _FeatureCard(
                tag: 'OP2',
                title: 'GPS માપણી',
                description: 'GPS દ્વારા જમીનની Boundary માપો, Area અને Distance ગણો અને Map પર જુઓ.',
                icon: Icons.location_on_outlined,
                iconColor: const Color(0xFF16A34A),
                background: const Color(0xFFEAF9ED),
                onTap: () => open(context, 'GPS માપણી', Icons.location_on_outlined, 'GPS boundary, area અને distance માટેનું પેજ.'),
              ),
              _FeatureCard(
                tag: 'OP3',
                title: 'Unit Conversion',
                description: 'ચો.મી., ચો.ફૂટ, ગુંઠા, એકર, હેક્ટર વગેરેમાં રૂપાંતર.',
                icon: Icons.swap_horiz,
                iconColor: const Color(0xFF5B2CB6),
                background: const Color(0xFFF0ECFF),
                onTap: () => open(context, 'Unit Conversion', Icons.swap_horiz, 'જમીનના વિવિધ units વચ્ચે conversion માટે તૈયાર પેજ.'),
              ),
              _FeatureCard(
                tag: 'OP4',
                title: 'Area Calculator',
                description: 'લંબચોરસ, ચોરસ, ત્રિકોણ અને અન્ય આકારોની જમીનનું ક્ષેત્રફળ ગણો.',
                icon: Icons.calculate_outlined,
                iconColor: const Color(0xFFF05A00),
                background: const Color(0xFFFFF0E3),
                onTap: () => open(context, 'Area Calculator', Icons.calculate_outlined, 'વિવિધ આકારોનું area ગણવા માટેનું calculator.'),
              ),
            ]),
            gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: width >= 650 ? 2 : 2,
              crossAxisSpacing: 12,
              mainAxisSpacing: 12,
              childAspectRatio: width >= 650 ? 1.45 : 0.93,
            ),
          ),
        ),
        SliverToBoxAdapter(
          child: Padding(
            padding: EdgeInsets.fromLTRB(horizontal, 0, horizontal, 24),
            child: const _HistoryCard(),
          ),
        ),
      ],
    );
  }
}

class _HeroHeader extends StatelessWidget {
  const _HeroHeader();

  @override
  Widget build(BuildContext context) {
    return Container(
      constraints: const BoxConstraints(minHeight: 315),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(28),
        gradient: const LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [Color(0xFF034B91), Color(0xFF058BD6), Color(0xFF1DB8D4)],
        ),
        boxShadow: const [
          BoxShadow(color: Color(0x22000000), blurRadius: 18, offset: Offset(0, 8)),
        ],
      ),
      child: Stack(
        children: [
          Positioned(
            right: -45,
            bottom: -35,
            child: Container(
              width: 190,
              height: 190,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: Colors.white.withOpacity(.08),
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(18, 18, 18, 20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    ClipRRect(
                      borderRadius: BorderRadius.circular(18),
                      child: Image.asset('assets/rudra_logo.jpg', width: 82, height: 82, fit: BoxFit.cover),
                    ),
                    const SizedBox(width: 14),
                    const Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text('RUDRA', style: TextStyle(fontSize: 38, height: .95, fontWeight: FontWeight.w900, color: Colors.white)),
                          Text('SURVEYOR', style: TextStyle(fontSize: 27, fontWeight: FontWeight.w800, color: Color(0xFFE6F5FF))),
                          SizedBox(height: 4),
                          Text('DGPS • DRONE • TOTAL STATION SURVEY', style: TextStyle(fontSize: 10, fontWeight: FontWeight.w700, color: Colors.white)),
                        ],
                      ),
                    ),
                    const Icon(Icons.settings_outlined, color: Colors.white, size: 30),
                  ],
                ),
                const Spacer(),
                const Text('નમસ્તે!', style: TextStyle(fontSize: 34, fontWeight: FontWeight.w800, color: Colors.white)),
                const SizedBox(height: 4),
                const Text('RUDR SURVEYOR માં આપનું સ્વાગત છે.', style: TextStyle(fontSize: 17, fontWeight: FontWeight.w500, color: Colors.white)),
                const SizedBox(height: 16),
                Row(
                  children: const [
                    _MiniPill(icon: Icons.gps_fixed, text: 'GPS'),
                    SizedBox(width: 8),
                    _MiniPill(icon: Icons.flight_takeoff, text: 'DRONE'),
                    SizedBox(width: 8),
                    _MiniPill(icon: Icons.straighten, text: 'SURVEY'),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _MiniPill extends StatelessWidget {
  final IconData icon;
  final String text;
  const _MiniPill({required this.icon, required this.text});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 7),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(.16),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: Colors.white.withOpacity(.24)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [Icon(icon, size: 16, color: Colors.white), const SizedBox(width: 5), Text(text, style: const TextStyle(color: Colors.white, fontSize: 11, fontWeight: FontWeight.w700))],
      ),
    );
  }
}

class _FeatureCard extends StatelessWidget {
  final String tag;
  final String title;
  final String description;
  final IconData icon;
  final Color iconColor;
  final Color background;
  final VoidCallback onTap;

  const _FeatureCard({
    required this.tag,
    required this.title,
    required this.description,
    required this.icon,
    required this.iconColor,
    required this.background,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Material(
      color: background,
      borderRadius: BorderRadius.circular(20),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(20),
        child: Padding(
          padding: const EdgeInsets.fromLTRB(14, 12, 12, 12),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 11, vertical: 5),
                decoration: BoxDecoration(color: iconColor, borderRadius: BorderRadius.circular(18)),
                child: Text(tag, style: const TextStyle(color: Colors.white, fontSize: 14, fontWeight: FontWeight.w800)),
              ),
              Expanded(
                child: Center(
                  child: Icon(icon, size: 62, color: iconColor),
                ),
              ),
              Text(title, style: TextStyle(fontSize: 21, fontWeight: FontWeight.w800, color: iconColor.withOpacity(.95))),
              const SizedBox(height: 4),
              Expanded(
                child: Text(description, maxLines: 4, overflow: TextOverflow.ellipsis, style: TextStyle(fontSize: 12.5, height: 1.35, color: iconColor.withOpacity(.90), fontWeight: FontWeight.w500)),
              ),
              Align(
                alignment: Alignment.bottomRight,
                child: CircleAvatar(
                  radius: 20,
                  backgroundColor: iconColor,
                  child: const Icon(Icons.arrow_forward, color: Colors.white),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _HistoryCard extends StatelessWidget {
  const _HistoryCard();

  @override
  Widget build(BuildContext context) {
    return Material(
      color: const Color(0xFFEAF5FF),
      borderRadius: BorderRadius.circular(22),
      child: InkWell(
        borderRadius: BorderRadius.circular(22),
        onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const SimplePage(title: 'Saved History', icon: Icons.history, subtitle: 'અગાઉની બધી નોંધ, માપણી અને પેમેન્ટ અહીંથી જુઓ અને ફરી ખોલો.'))),
        child: Padding(
          padding: const EdgeInsets.all(18),
          child: Column(
            children: [
              Row(
                children: [
                  const CircleAvatar(radius: 31, backgroundColor: Color(0xFF0878D1), child: Icon(Icons.history, color: Colors.white, size: 34)),
                  const SizedBox(width: 14),
                  const Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text('Saved History', style: TextStyle(fontSize: 24, fontWeight: FontWeight.w800, color: Color(0xFF124D86))),
                        SizedBox(height: 2),
                        Text('અગાઉની બધી નોંધ, માપણી અને પેમેન્ટ અહીંથી જુઓ અને ફરી ખોલો.', style: TextStyle(fontSize: 13, height: 1.35, color: Color(0xFF164D7F))),
                      ],
                    ),
                  ),
                  const Icon(Icons.arrow_forward, color: Color(0xFF0878D1), size: 32),
                ],
              ),
              const SizedBox(height: 14),
              Row(
                children: const [
                  Expanded(child: _Stat(title: 'કુલ નોંધ', value: '12', icon: Icons.description_outlined)),
                  SizedBox(width: 8),
                  Expanded(child: _Stat(title: 'કુલ માપણી', value: '8', icon: Icons.location_on_outlined)),
                  SizedBox(width: 8),
                  Expanded(child: _Stat(title: 'કુલ પેમેન્ટ', value: '₹ 1,85,000', icon: Icons.currency_rupee)),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _Stat extends StatelessWidget {
  final String title, value;
  final IconData icon;
  const _Stat({required this.title, required this.value, required this.icon});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 10),
      decoration: BoxDecoration(color: Colors.white.withOpacity(.45), borderRadius: BorderRadius.circular(15)),
      child: Column(
        children: [
          Icon(icon, color: const Color(0xFF0878D1), size: 23),
          const SizedBox(height: 4),
          Text(title, textAlign: TextAlign.center, style: const TextStyle(fontSize: 10, color: Color(0xFF174D7C))),
          const SizedBox(height: 1),
          FittedBox(child: Text(value, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w800, color: Color(0xFF123F70)))),
        ],
      ),
    );
  }
}

class SimplePage extends StatelessWidget {
  final String title;
  final IconData icon;
  final String subtitle;

  const SimplePage({super.key, required this.title, required this.icon, required this.subtitle});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(title, style: const TextStyle(fontWeight: FontWeight.w800)),
        backgroundColor: Colors.transparent,
      ),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(28),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              CircleAvatar(radius: 48, backgroundColor: const Color(0xFFE5F2FF), child: Icon(icon, size: 52, color: const Color(0xFF0878D1))),
              const SizedBox(height: 22),
              Text(title, textAlign: TextAlign.center, style: const TextStyle(fontSize: 28, fontWeight: FontWeight.w800)),
              const SizedBox(height: 10),
              Text(subtitle, textAlign: TextAlign.center, style: const TextStyle(fontSize: 16, height: 1.5)),
              const SizedBox(height: 28),
              FilledButton.icon(
                onPressed: () => Navigator.of(context).maybePop(),
                icon: const Icon(Icons.arrow_back),
                label: const Text('પાછા Home પર'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
